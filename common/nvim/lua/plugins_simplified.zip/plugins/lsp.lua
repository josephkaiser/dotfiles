-- plugins/lsp.lua
return {
  { "williamboman/mason.nvim", build = ":MasonUpdate", opts = {} },
  { "neovim/nvim-lspconfig" },
  {
    "williamboman/mason-lspconfig.nvim",
    dependencies = { "williamboman/mason.nvim", "neovim/nvim-lspconfig", "hrsh7th/cmp-nvim-lsp" },
    config = function()
      require("mason").setup()
      local mlsp = require("mason-lspconfig")
      mlsp.setup({ automatic_installation = true })
      local capabilities = vim.lsp.protocol.make_client_capabilities()
      local ok, cmp = pcall(require, "cmp_nvim_lsp")
      if ok and cmp.default_capabilities then
        capabilities = cmp.default_capabilities(capabilities)
      end
      local lspconfig = require("lspconfig")
      mlsp.setup_handlers({
        function(server) lspconfig[server].setup({ capabilities = capabilities }) end,
      })
    end,
  },
}