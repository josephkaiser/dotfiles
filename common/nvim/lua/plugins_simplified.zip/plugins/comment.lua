-- plugins/comment.lua
return {
  "numToStr/Comment.nvim",
  event = "VeryLazy",
  opts = {},
}