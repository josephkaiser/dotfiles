-- plugins/lazy.lua
-- Keep your lazy.nvim bootstrap here if you had one. Minimal placeholder:
return {}