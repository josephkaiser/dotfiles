-- lua/plugins/lsp.lua
return {
  {
    "williamboman/mason.nvim",
    build = ":MasonUpdate",
    config = function()
      require("mason").setup()
    end,
  },
  { "neovim/nvim-lspconfig" },
  {
    "williamboman/mason-lspconfig.nvim",
    dependencies = {
      "williamboman/mason.nvim",
      "neovim/nvim-lspconfig",
      "hrsh7th/cmp-nvim-lsp", -- optional but enables proper capabilities
    },
    -- config = function()
    --   local ok_mlc, mason_lspconfig = pcall(require, "mason-lspconfig")
    --   if not ok_mlc then return end
    --   local ok_lsp, lspconfig = pcall(require, "lspconfig")
    --   if not ok_lsp then return end
    --
    --   local servers = { "lua_ls", "pyright", "bashls", "clangd" }
    --
    --   mason_lspconfig.setup({
    --     ensure_installed = servers,
    --     automatic_installation = true,
    --   })
    --
    --   -- capabilities (works with/without cmp)
    --   local capabilities = vim.lsp.protocol.make_client_capabilities()
    --   local ok_cmp, cmp = pcall(require, "cmp_nvim_lsp")
    --   if ok_cmp and cmp.default_capabilities then
    --     capabilities = cmp.default_capabilities(capabilities)
    --   end
    --
    --   local function map(bufnr, mode, lhs, rhs, desc)
    --     vim.keymap.set(mode, lhs, rhs, { buffer = bufnr, silent = true, desc = desc })
    --   end
    --
    --   local function on_attach(_, bufnr)
    --     -- leader under <leader>l... to avoid <leader>e conflicts
    --     map(bufnr, "n", "<leader>lr", vim.lsp.buf.rename,          "LSP: Rename")
    --     map(bufnr, "n", "<leader>la", vim.lsp.buf.code_action,      "LSP: Code action")
    --     map(bufnr, "n", "<leader>le", vim.diagnostic.open_float,    "LSP: Line diagnostics")
    --     -- navigation
    --     map(bufnr, "n", "gd",        vim.lsp.buf.definition,        "LSP: Definition")
    --     map(bufnr, "n", "gr",        vim.lsp.buf.references,        "LSP: References")
    --     map(bufnr, "n", "K",         vim.lsp.buf.hover,             "LSP: Hover")
    --     map(bufnr, "n", "[d",        vim.diagnostic.goto_prev,      "Prev diagnostic")
    --     map(bufnr, "n", "]d",        vim.diagnostic.goto_next,      "Next diagnostic")
    --   end
    --
    --   local function setup_server(server_name)
    --     local opts = { capabilities = capabilities, on_attach = on_attach }
    --     if server_name == "lua_ls" then
    --       opts.settings = {
    --         Lua = {
    --           workspace = { checkThirdParty = false },
    --           diagnostics = { globals = { "vim" } },
    --           hint = { enable = true },
    --         },
    --       }
    --     end
    --     lspconfig[server_name].setup(opts)
    --   end
    --
    --   -- Prefer setup_handlers if available; otherwise fall back
    --   if type(mason_lspconfig.setup_handlers) == "function" then
    --     mason_lspconfig.setup_handlers({
    --       function(server_name) setup_server(server_name) end,
    --     })
    --   else
    --     -- old mason-lspconfig fallback
    --     for _, server_name in ipairs(mason_lspconfig.get_installed_servers()) do
    --       setup_server(server_name)
    --     end
      -- end
    -- end,
  },
}
