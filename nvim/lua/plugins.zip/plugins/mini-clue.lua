return {
  "echasnovski/mini.clue",
  version = false,
  config = function()
    local miniclue = require("mini.clue")
    local global_clues = require("config.keymaps").clues()

    -- add plugin leader clues here
    local plugin_leader_clues = {
      { mode = "n", keys = "<leader>e", desc = "Toggle file tree" },   -- nvim-tree
      { mode = "n", keys = "<leader>n", desc = "Next buffer" },        -- bufferline
      { mode = "n", keys = "<leader>p", desc = "Previous buffer" },    -- bufferline
      { mode = "n", keys = "<leader>x", desc = "Close buffer" },    -- bufferline
      { mode = "n", keys = "<leader>=b", desc = "Format with Black" },    -- format Black
      
      -- persistence.nvim 
      { mode = "n", keys = "<leader>qs", desc = "Restore session" },
      { mode = "n", keys = "<leader>ql", desc = "Restore last session" },
      { mode = "n", keys = "<leader>qd", desc = "Don't save session" },
      { mode = "n", keys = "<leader>qS", desc = "Save session now" },

      -- telescope keymaps
      { mode = "n", keys = "<leader>ff", desc = "Find files" },
      { mode = "n", keys = "<leader>fg", desc = "Live grep" },
      { mode = "n", keys = "<leader>fb", desc = "Buffers list" },
      { mode = "n", keys = "<leader>fh", desc = "Help tags" },

      -- LSP keymaps
      { mode = "n", keys = "gd",       desc = "Go to definition" },
      { mode = "n", keys = "gr",       desc = "References" },
      { mode = "n", keys = "K",        desc = "Hover docs" },
      { mode = "n", keys = "<leader>rn", desc = "Rename symbol" },
      { mode = "n", keys = "<leader>ca", desc = "Code action" },
      { mode = "n", keys = "[d",       desc = "Prev diagnostic" },
      { mode = "n", keys = "]d",       desc = "Next diagnostic" },
      { mode = "n", keys = "<leader>lr", desc = "LSP: Rename" },
      { mode = "n", keys = "<leader>la", desc = "LSP: Code action" },
      { mode = "n", keys = "<leader>le",  desc = "LSP: Line diagnostics" },

      -- DAP keymaps
      { mode = "n", keys = "<leader>db", desc = "Toggle breakpoint" },
      { mode = "n", keys = "<leader>dB", desc = "Clear breakpoints" },
      { mode = "n", keys = "<leader>dc", desc = "Continue" },
      { mode = "n", keys = "<leader>dn", desc = "Step over" },
      { mode = "n", keys = "<leader>di", desc = "Step into" },
      { mode = "n", keys = "<leader>do", desc = "Step out" },
      { mode = "n", keys = "<leader>dr", desc = "Restart" },
      { mode = "n", keys = "<leader>dq", desc = "Terminate" },
      { mode = "n", keys = "<leader>dU", desc = "Toggle DAP UI" },

      -- treesitter keymaps for textobjects selection
      { mode = "o", keys = "<CR>",   desc = "TS: Node incremental" },
      { mode = "x", keys = "<CR>",   desc = "TS: Node incremental" },
      { mode = "o", keys = "<S-CR>", desc = "TS: Scope incremental" },
      { mode = "x", keys = "<S-CR>", desc = "TS: Scope incremental" },
      { mode = "o", keys = "<BS>",   desc = "TS: Node decremental" },
      { mode = "x", keys = "<BS>",   desc = "TS: Node decremental" },

      -- iron.nvim (REPL)
      { mode = "n", keys = "<leader>rr", desc = "Toggle REPL" },
      { mode = "n", keys = "<leader>rR", desc = "Restart REPL" },
      { mode = "n", keys = "<leader>sc", desc = "Send motion" },
      { mode = "v", keys = "<leader>sc", desc = "Send selection" },
      { mode = "n", keys = "<leader>sf", desc = "Send file" },
      { mode = "n", keys = "<leader>sl", desc = "Send line" },
      { mode = "n", keys = "<leader>sp", desc = "Send paragraph" },
      { mode = "n", keys = "<leader>su", desc = "Send to cursor" },
      { mode = "n", keys = "<leader>sm", desc = "Send mark" },
      { mode = "n", keys = "<leader>sb", desc = "Send code block" },
      { mode = "n", keys = "<leader>sn", desc = "Send block + next" },
      { mode = "n", keys = "<leader>mc", desc = "Mark motion" },
      { mode = "v", keys = "<leader>mc", desc = "Mark selection" },
      { mode = "n", keys = "<leader>md", desc = "Remove mark" },
      { mode = "n", keys = "<leader>s<cr>", desc = "Send CR to REPL" },
      { mode = "n", keys = "<leader>s<leader>", desc = "Interrupt REPL" },
      { mode = "n", keys = "<leader>sq", desc = "Quit REPL" },
      { mode = "n", keys = "<leader>cl", desc = "Clear REPL" },
    }

    miniclue.setup({
      triggers = {
        { mode = "n", keys = "<leader>" },
        { mode = "v", keys = "<leader>" },
        { mode = "n", keys = "g" },
        { mode = "n", keys = "]" },
        { mode = "n", keys = "[" },
      },
      clues = vim.list_extend(
        vim.list_extend({
          miniclue.gen_clues.builtin_completion(),
          miniclue.gen_clues.g(),
          miniclue.gen_clues.marks(),
          miniclue.gen_clues.registers(),
          miniclue.gen_clues.windows(),
          miniclue.gen_clues.z(),
        }, global_clues),
        plugin_leader_clues
      ),
      window = { delay = 100, config = { border = "single" } },
    })
  end,
}
