-- lua/plugins/nvim-tree.lua
return {
  "nvim-tree/nvim-tree.lua",
  version = "*",
  dependencies = { "nvim-tree/nvim-web-devicons" },

  -- load when the key or any of these commands are used
  keys = {
    { "<leader>e", "<cmd>NvimTreeToggle<cr>", desc = "File explorer" },
  },
  cmd = { "NvimTreeToggle", "NvimTreeOpen", "NvimTreeClose", "NvimTreeFocus", "NvimTreeFindFile", "NvimTreeFindFileToggle" },

  init = function()
    vim.g.loaded_netrw = 1
    vim.g.loaded_netrwPlugin = 1

    -- Failsafe shim: create the command early; first call loads plugin then reruns
    if vim.fn.exists(":NvimTreeToggle") == 0 then
      vim.api.nvim_create_user_command("NvimTreeToggle", function()
        require("lazy").load({ plugins = { "nvim-tree.lua" } })
        require("nvim-tree.api").tree.toggle()
      end, {})
    end
  end,

  config = function()
    require("nvim-tree").setup({
      disable_netrw = true,
      hijack_netrw = true,
      sync_root_with_cwd = true,
      update_focused_file = { enable = true, update_root = false },
      view = { width = 34 },
      renderer = { group_empty = true },
    })
  end,
}
