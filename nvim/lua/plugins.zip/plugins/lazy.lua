return {
  "folke/lazy.nvim",
}
